# PB Blaze Mobilador – project uji

Ini adalah **project sumber untuk pengujian**, bukan APK hasil perbaikan yang sudah teruji.

## Apa yang diuji
- Membuka `https://www.pbblaze.com.br/` melalui Android WebView.
- Mengaktifkan JavaScript dan DOM Storage.
- Meneruskan event mouse Android ke WebView.
- Tombol **Ativar mouse** meminta Android melakukan pointer capture native.
- Tombol ESC mencoba melepaskan pointer capture.

## Batasan penting
Pointer capture Android native tidak sama dengan JavaScript Pointer Lock API (`requestPointerLock`). Jika WebView Chromium pada perangkat tidak mengimplementasikan Pointer Lock, project ini tidak dapat memaksanya aktif. Tombol ini hanya menguji apakah Android dapat menangkap pointer untuk view.

## Build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle sync selesai.
3. Gunakan Android SDK 35 dan JDK 17.
4. Pilih `Build > Build APK(s)`.

Project memakai applicationId `br.com.pbblaze.mobilador.test` agar bisa dipasang berdampingan dengan APK asli. Ini bukan update langsung untuk APK asli; tanda tangan kunci berbeda dan source/kunci penandatanganan asli tidak tersedia.

## Keamanan
Project hanya memuat situs resmi yang tertulis di source. Tidak ada bypass anti-cheat, modifikasi gameplay, atau akses ke akun.
