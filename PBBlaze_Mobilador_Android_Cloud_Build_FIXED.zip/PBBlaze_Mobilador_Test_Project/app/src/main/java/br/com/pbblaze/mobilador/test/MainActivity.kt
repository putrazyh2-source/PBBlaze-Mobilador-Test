package br.com.pbblaze.mobilador.test

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private val gameUrl = "https://www.pbblaze.com.br/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        webView = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            isFocusable = true
            isFocusableInTouchMode = true
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                builtInZoomControls = false
                displayZoomControls = false
            }
            setOnGenericMotionListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_HOVER_MOVE,
                    MotionEvent.ACTION_HOVER_ENTER,
                    MotionEvent.ACTION_HOVER_EXIT,
                    MotionEvent.ACTION_SCROLL -> false
                    else -> false
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                status.text = "PB Blaze carregado • toque em Ativar mouse"
            }
        }
        webView.webChromeClient = WebChromeClient()

        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        val controls = FrameLayout(this)

        val activate = Button(this).apply {
            text = "Ativar mouse"
            setOnClickListener {
                webView.requestFocus()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    webView.requestPointerCapture()
                    Toast.makeText(
                        this@MainActivity,
                        "Solicitação de captura nativa enviada. O suporte ao Pointer Lock do WebView depende da versão do WebView.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Captura nativa do ponteiro requer Android 8.0 ou superior.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        controls.addView(
            activate,
            FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(12, 12, 18, 18)
            }
        )

        status = TextView(this).apply {
            text = "Abrindo PB Blaze…"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xAA111111.toInt())
            textSize = 12f
            setPadding(12, 8, 12, 8)
        }
        controls.addView(
            status,
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
                setMargins(12, 12, 12, 12)
            }
        )
        root.addView(controls)
        setContentView(root)
        webView.loadUrl(gameUrl)
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        super.onPointerCaptureChanged(hasCapture)
        if (::status.isInitialized) {
            status.text = if (hasCapture) {
                "Android capturou o mouse • pressione ESC para liberar"
            } else {
                "Captura mouse desligada"
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_ESCAPE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.releasePointerCapture()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
