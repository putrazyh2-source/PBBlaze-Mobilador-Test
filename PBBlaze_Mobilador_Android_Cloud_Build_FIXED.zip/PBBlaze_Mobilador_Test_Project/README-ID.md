# PB Blaze Mobilador – project uji (konfigurasi JVM diperbaiki)

Project pengujian Android WebView. Java dan Kotlin sama-sama menargetkan JVM 17.

## Build cloud
ZIP ini perlu diekstrak menjadi folder `PBBlaze_Mobilador_Test_Project_Fixed`. Jika workflow masih menggunakan nama folder lama, ubah `working-directory` dan path artifact agar sesuai dengan nama folder ini.

## Batasan
Ini bukan APK final atau pembaruan langsung APK asli. Dukungan Android pointer capture native tidak menjamin dukungan JavaScript Pointer Lock API di WebView. Uji pada perangkat diperlukan. Tidak ada bypass anti-cheat atau modifikasi gameplay.
