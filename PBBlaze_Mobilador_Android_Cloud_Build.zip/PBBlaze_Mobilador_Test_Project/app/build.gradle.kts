plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.pbblaze.mobilador.test"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.pbblaze.mobilador.test"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-test"
    }
}
