package br.com.pbblaze.mobilador.test

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView

    // Keep this test package separate from the supplied APK so it can be installed
    // alongside the original app without replacing it.
    private val gameUrl = "https://www.pbblaze.com.br/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        webView = WebView(this)
        webView.setBackgroundColor(0xFF000000.toInt())
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                status.text = "PB Blaze carregado • toque em Ativar mouse"
            }
        }
        webView.webChromeClient = WebChromeClient()

        // Let Android/WebView process real mouse motion and button events.
        webView.setOnGenericMotionListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_MOVE,
                MotionEvent.ACTION_HOVER_ENTER,
                MotionEvent.ACTION_HOVER_EXIT,
                MotionEvent.ACTION_SCROLL -> false
                else -> false
            }
        }

        root.addView(
            webView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val controls = FrameLayout(this)
        val activate = Button(this).apply {
            text = "Ativar mouse"
            setOnClickListener {
                webView.requestFocus()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    webView.requestPointerCapture()
                    Toast.makeText(
                        this@MainActivity,
                        "Solicitação de captura enviada ao Android. Isso não garante suporte ao Pointer Lock do WebView.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Captura nativa do ponteiro requer Android 8.0 ou superior.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        val buttonParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        ).apply {
            setMargins(12, 12, 18, 18)
        }
        controls.addView(activate, buttonParams)

        status = TextView(this).apply {
            text = "Abrindo PB Blaze…"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xAA111111.toInt())
            textSize = 12f
            setPadding(12, 8, 12, 8)
        }
        val statusParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START
        ).apply {
            setMargins(12, 12, 12, 12)
        }
        controls.addView(status, statusParams)
        root.addView(controls)

        setContentView(root)
        webView.loadUrl(gameUrl)
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        super.onPointerCaptureChanged(hasCapture)
        if (::status.isInitialized) {
            status.text = if (hasCapture) {
                "Android capturou o mouse • pressione ESC para liberar"
            } else {
                "Captura mouse desligada"
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_ESCAPE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.releasePointerCapture()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
